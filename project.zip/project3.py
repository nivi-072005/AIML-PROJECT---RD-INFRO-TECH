import numpy as np
 # Sample user-item matrix (ratings) and binge-worthiness scores
 # Each row represents a user, and each column represents an item (show)
 # Values are ratings given by users to items (0 represents no rating)
 # Binge-worthiness scores represent how binge-worthy a show is (1 to 5 scale)
 user_item_matrix = np.array([
 [5, 0, 4, 0, 3],
 [0, 4, 0, 0, 5],
 [4, 0, 5, 3, 0],
 [0, 2, 0, 4, 0],
 [3, 0, 4, 0, 5]
 ])
 binge_scores = np.array([5, 4, 3, 2, 5]) # Example binge-worthiness scores for each show
 # Function to calculate similarity between users using cosine similarity
 def cosine_similarity(user_item_matrix):
 similarity_matrix = np.zeros((user_item_matrix.shape[0], user_item_matrix.shape[0]))
 for i in range(len(user_item_matrix)):
 for j in range(len(user_item_matrix)):
if i != j:
 similarity_matrix[i, j] = np.dot(user_item_matrix[i], user_item_matrix[j]) /
 (np.linalg.norm(user_item_matrix[i]) * np.linalg.norm(user_item_matrix[j]))
 return similarity_matrix
 # Function to generate recommendations for a user
 def generate_recommendations(user_id, user_item_matrix, similarity_matrix, binge_scores, k=2):
 user_ratings = user_item_matrix[user_id]
 # Find k most similar users
 similar_users = np.argsort(similarity_matrix[user_id])[::-1][:k]
 # Predict ratings for items user hasn't rated yet based on binge-worthiness
 recommendations = np.zeros(user_item_matrix.shape[1])
 for i in range(len(user_ratings)):
 if user_ratings[i] == 0:
 numerator = 0
 denominator = 0
 for user in similar_users:
 if user_item_matrix[user, i] != 0:
 numerator += similarity_matrix[user_id, user] * (user_item_matrix[user, i] *
 binge_scores[i])
 denominator += abs(similarity_matrix[user_id, user])
 if denominator != 0:
 recommendations[i] = numerator / denominator
 return recommendations
 # Example usage
similarity_matrix = cosine_similarity(user_item_matrix)
 user_id = 0 # Choose a user
 recommendations = generate_recommendations(user_id, user_item_matrix, similarity_matrix,
 binge_scores)
 print("Recommendations for User", user_id, ":", recommendations)
