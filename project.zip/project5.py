import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.layers import Input, Dense, Embedding, LSTM, Concatenate
from tensorflow.keras.models import Model
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.models import load_model
from sklearn.model_selection import train_test_split
from nltk.translate.bleu_score import corpus_bleu
import os
import json

# Load COCO dataset
def load_coco_data(data_dir):
    with open(os.path.join(data_dir, 'annotations', 'captions_train2017.json'), 'r') as f:
        annotations = json.load(f)

    image_dir = os.path.join(data_dir, 'train2017')
    image_paths = []
    captions = []

    for annot in annotations['annotations']:
        captions.append(annot['caption'])
        image_paths.append(os.path.join(image_dir, '%012d.jpg' % annot['image_id']))

    return image_paths, captions

# Load and preprocess images
def preprocess_images(image_paths):
    model = ResNet50(include_top=False, weights='imagenet', input_shape=(224, 224, 3))
    image_features = []

    for image_path in image_paths:
        img = load_img(image_path, target_size=(224, 224))
        img = img_to_array(img)
        img = preprocess_input(img)
        img_features = model.predict(np.expand_dims(img, axis=0))
        image_features.append(img_features.flatten())

    return np.array(image_features)

# Tokenize and preprocess captions
def preprocess_captions(captions):
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(captions)
    sequences = tokenizer.texts_to_sequences(captions)
    max_sequence_length = max([len(seq) for seq in sequences])
    vocab_size = len(tokenizer.word_index) + 1

    return sequences, max_sequence_length, vocab_size, tokenizer

# Create data generator
def data_generator(images, sequences, vocab_size, max_sequence_length, batch_size):
    while True:
        for i in range(0, len(images), batch_size):
            X_images = images[i:i+batch_size]
            X_sequences = sequences[i:i+batch_size]
            y = []
            for sequence in X_sequences:
                for i in range(1, len(sequence)):
                    in_sequence = sequence[:i]
                    out_sequence = sequence[i]
                    out_sequence = to_categorical([out_sequence], num_classes=vocab_size)[0]
                    y.append((in_sequence, out_sequence))
            X_images = np.array(X_images)
            X_sequences = pad_sequences(X_sequences, maxlen=max_sequence_length, padding='post')
            y = np.array(y)
            yield [X_images, X_sequences], y

# Define model architecture
def define_model(max_sequence_length, vocab_size):
    image_input = Input(shape=(2048,))
    image_dense = Dense(256, activation='relu')(image_input)
    image_embedding = Dense(256, activation='relu')(image_dense)

    caption_input = Input(shape=(max_sequence_length,))
    caption_embedding = Embedding(vocab_size, 256, mask_zero=True)(caption_input)
    caption_lstm = LSTM(256)(caption_embedding)

    decoder = Concatenate()([image_embedding, caption_lstm])
    decoder = Dense(256, activation='relu')(decoder)
    output = Dense(vocab_size, activation='softmax')(decoder)

    model = Model(inputs=[image_input, caption_input], outputs=output)
    model.compile(loss='categorical_crossentropy', optimizer='adam')

    return model

# Load data
image_paths, captions = load_coco_data('path/to/coco_data')
image_features = preprocess_images(image_paths)
sequences, max_sequence_length, vocab_size, tokenizer = preprocess_captions(captions)
X_train_images, X_test_images, X_train_sequences, X_test_sequences = train_test_split(image_features, sequences, test_size=0.1)

# Define model
model = define_model(max_sequence_length, vocab_size)
model.summary()

# Train model
batch_size = 64
epochs = 10
steps_per_epoch = len(X_train_images) // batch_size
train_generator = data_generator(X_train_images, X_train_sequences, vocab_size, max_sequence_length, batch_size)
test_generator = data_generator(X_test_images, X_test_sequences, vocab_size, max_sequence_length, batch_size)

model.fit(train_generator, epochs=epochs, steps_per_epoch=steps_per_epoch, validation_data=test_generator, validation_steps=10)

# Save model
model.save('image_caption_model.h5')

# Evaluate model (BLEU score)
def evaluate_model(model, images, sequences, tokenizer, max_sequence_length):
    actual, predicted = [], []
    for i, image in enumerate(images):
        yhat = generate_caption(model, image, tokenizer, max_sequence_length)
        references = [tokenizer.sequences_to_texts([sequence])[0].split() for sequence in sequences[i]]
        actual.append(references)
        predicted.append(yhat.split())
    bleu_score = corpus_bleu(actual, predicted)
    return bleu_score

# Generate caption for an image
def generate_caption(model, image, tokenizer, max_sequence_length):
    in_text = 'startseq'
    for _ in range(max_sequence_length):
        sequence = tokenizer.texts_to_sequences([in_text])[0]
        sequence = pad_sequences([sequence], maxlen=max_sequence_length)
        yhat = model.predict([np.array([image]), np.array(sequence)], verbose=0)
        yhat = np.argmax(yhat)
        word = word_for_id(yhat, tokenizer)
        if word is None:
            break
        in_text += ' ' + word
        if word == 'endseq':
            break
    return in_text

# Map an integer to a word
def word_for_id(integer, tokenizer):
    for word, index in tokenizer.word_index.items():
        if index == integer:
            return word
    return None

# Evaluate model
bleu_score = evaluate_model(model, X_test_images[:100], X_test_sequences[:100], tokenizer, max_sequence_length)
print('BLEU Score:', bleu_score)
