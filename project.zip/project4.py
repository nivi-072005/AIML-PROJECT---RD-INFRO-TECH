import cv2
 import dlib
 # Load pre-trained face detection model (Haar cascades)
 face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades +
 'haarcascade_frontalface_default.xml')
 # Load pre-trained facial landmark detection model (dlib)
 predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
 # Load pre-trained face recognition model (dlib)
 face_recognition_model =
 dlib.face_recognition_model_v1("dlib_face_recognition_resnet_model_v1.dat")
 # Function to detect faces in an image
 def detect_faces(image):
 gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
 faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30,
30))
 return faces
 # Function to recognize faces in an image
 def recognize_faces(image, faces):
 gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
 recognized_faces = []
 for (x, y, w, h) in faces:
 # Detect facial landmarks
 rect = dlib.rectangle(int(x), int(y), int(x + w), int(y + h))
 shape = predictor(gray, rect)
 # Recognize face using pre-trained face recognition model
 face_descriptor = face_recognition_model.compute_face_descriptor(image, shape)
 recognized_faces.append(face_descriptor) # Store face descriptor for recognition
 # Drawrectangle around detected face
 cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
 return recognized_faces, image
 # Example usage
 image_path = "example_image.jpg" # Path to the input image
 image = cv2.imread(image_path)
# Detect faces in the image
 faces = detect_faces(image)
 # Recognize faces in the image
 recognized_faces, image_with_faces = recognize_faces(image, faces)
 # Display the image with detected faces
 cv2.imshow("Faces Detected", image_with_faces)
 cv2.waitKey(0)
 cv2.destroyAllWindows()
